# Data Science & ML Career Roadmap

A responsive, single-page GitHub Pages website for an AWS, Databricks, time-series analytics, MLOps, and renewable-energy machine learning learning plan.

## Deploy with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/root`.
6. Save and open the generated GitHub Pages URL.

The checklist and skill tracker use browser `localStorage`, so progress is saved in the browser being used.
